
<?php
session_start();

$valid_username = "admin";
$valid_password = "sman9lt";

if (isset($_POST['username']) && isset($_POST['password'])) {
  if ($_POST['username'] === $valid_username && $_POST['password'] === $valid_password) {
    $_SESSION['logged_in'] = true;
    header("Location: upload.php");
    exit();
  } else {
    $error = "Username atau password salah!";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login - Upload File Alumni</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .login-container {
      background: #ffffff;
      padding: 20px;
      max-width: 400px;
      margin: 50px auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 8px;
      text-align: center;
    }

    .login-container input {
      width: 90%;
      padding: 10px;
      margin-bottom: 15px;
    }

    .login-container button {
      padding: 10px 20px;
      background-color: #1976d2;
      color: white;
      border: none;
      border-radius: 5px;
    }

    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Login untuk Upload File</h2>
    <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Username" required><br>
      <input type="password" name="password" placeholder="Password" required><br>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
