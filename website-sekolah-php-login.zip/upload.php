<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  header("Location: login.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Upload File Alumni</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .upload-container {
      background: #ffffff;
      padding: 20px;
      max-width: 600px;
      margin: 30px auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 8px;
    }

    .upload-container label {
      display: block;
      margin-bottom: 10px;
      font-weight: bold;
    }

    .upload-container input[type="file"] {
      width: 100%;
      margin-bottom: 20px;
    }

    .upload-container button {
      background-color: #1976d2;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .uploaded-files {
      margin-top: 20px;
    }

    .uploaded-files ul {
      list-style: none;
      padding: 0;
    }

    .uploaded-files li {
      padding: 5px 0;
      border-bottom: 1px solid #ddd;
    }

    .uploaded-files a {
      color: #333;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <header>
    <h1>Upload File Alumni</h1>
  </header>

  <main>
    <div class="upload-container">
      <?php
      if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["fileUpload"])) {
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
          mkdir($uploadDir, 0777, true);
        }
        $targetFile = $uploadDir . basename($_FILES["fileUpload"]["name"]);
        if (move_uploaded_file($_FILES["fileUpload"]["tmp_name"], $targetFile)) {
          echo "<p style='color:green;'>File berhasil diupload: " . htmlspecialchars(basename($_FILES["fileUpload"]["name"])) . "</p>";
        } else {
          echo "<p style='color:red;'>Gagal upload file.</p>";
        }
      }
      ?>

      <form method="POST" enctype="multipart/form-data">
        <label for="fileUpload">Pilih File (PDF/Gambar):</label>
        <input type="file" name="fileUpload" id="fileUpload" required>
        <button type="submit">Upload</button>
      </form>

      <div class="uploaded-files">
        <h3>File yang Sudah Diunggah:</h3>
        <ul>
          <?php
          $uploadDir = "uploads/";
          if (file_exists($uploadDir)) {
            $files = scandir($uploadDir);
            foreach ($files as $file) {
              if ($file !== "." && $file !== "..") {
                echo "<li><a href='$uploadDir$file' target='_blank'>$file</a></li>";
              }
            }
          } else {
            echo "<li>Belum ada file diunggah.</li>";
          }
          ?>
        </ul>
      </div>
    </div>
  </main>

  <footer>
    <p>&copy; 2025 SMAN 9 LUWU TIMUR. All rights reserved.</p>
  </footer>
</body>
</html>
